# Apply this on top of `main`

`main` already has the frame sequence, logo, real menu and Vercel prep (merged
as PR #1). This archive is **only the Supabase layer** — the backend, the admin
dashboard and the hero video. Nothing here overwrites that earlier work except
five files that were genuinely modified, listed at the bottom.

## Fastest route (paste this to the agent)

> Unzip `supabase-layer.zip` at the repo root (it extracts in place), delete
> the zip and this file, run `npm install`, then
> `npm run db:test && npm run typecheck && npm run lint && npm run build`.
> If all four pass, commit and open a PR.

## Manual route

```bash
unzip -o supabase-layer.zip -d .      # from the repo root; extracts in place
rm supabase-layer.zip SUPABASE-LAYER-APPLY.md
npm install                            # picks up the 4 new dependencies
npm run db:test                        # 39 RLS checks against a real Postgres
npm run typecheck
npm run lint
npm run build
```

All four must pass. `db:test` is the one that matters — it applies the real
migration files to an in-process Postgres and asserts that an anonymous visitor
cannot read the reservation list, cannot self-approve a booking and cannot see
unpublished content, and that a signed-up non-admin can change nothing.

## New dependencies

`package.json` and `package-lock.json` are included, so `npm install` is enough:

| Package | Why |
| --- | --- |
| `@supabase/supabase-js` | Database and auth client |
| `@supabase/ssr` | Cookie-based sessions for the App Router |
| `tus-js-client` | Resumable uploads for hero videos over ~6 MB |
| `@electric-sql/pglite` *(dev)* | In-process Postgres used by `npm run db:test` |

## Files that MODIFY existing ones

Everything else in this archive is new. These five replace what is on `main`:

| File | Change |
| --- | --- |
| `app/page.tsx` | Async Server Component; picks hero video **or** the frame sequence; `revalidate = 60` |
| `components/Menu.tsx` | Takes a `categories` prop, defaulting to the committed menu |
| `package.json` | New deps and the `db:test` / `seed:generate` scripts |
| `README.md` | Architecture and Supabase sections added |
| `.gitignore` | Ignores `.env` / `.env.local` |

`app/page.tsx` and `components/Menu.tsx` are backwards compatible: with no
Supabase configured the site renders exactly as it does today, from `data/`.

## After it is merged

Database setup is in `supabase/README.md` — about ten minutes. The site runs
fine without it; only `/admin` is unavailable until the two environment
variables are set.
