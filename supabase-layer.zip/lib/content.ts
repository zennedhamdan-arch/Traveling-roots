import "server-only";

import { cache } from "react";

import { isSupabaseConfigured } from "@/lib/supabase/env";
import { createSupabasePublicClient } from "@/lib/supabase/public";
import type {
  ExperienceRow,
  GalleryItemRow,
  HeroMediaRow,
  MenuCategoryRow,
  MenuItemRow,
  MenuSectionRow,
  OfferRow,
  SocialLinkRow,
  TestimonialRow,
} from "@/lib/supabase/types";
import {
  menu as staticMenu,
  type DietaryTag,
  type MenuCategoryData,
  type MenuItem,
  type MenuSection,
} from "@/data/menu";
import { restaurant as staticRestaurant, type RestaurantData } from "@/data/restaurant";

/**
 * The public site's content layer.
 *
 * Every loader follows the same rule:
 *
 *   Supabase configured and returns rows  →  use the database
 *   Supabase absent, erroring, or empty   →  use the committed data in data/
 *
 * The fallback is not defensive padding, it is the product decision. The
 * restaurant's phone number, address and full menu are already correct in the
 * repo. A missing environment variable, a paused Supabase project or a network
 * blip must not take that off the internet — the worst outcome should be that
 * a recent edit isn't shown yet, never a blank menu.
 *
 * `cache()` deduplicates within a single render pass, so a loader used by both
 * the page and the structured data runs one query, not two.
 */

/** RWF has no minor unit, so an integer is the whole price. */
export function formatPrice(amount: number | null): string | null {
  if (amount === null) return null;
  return `${amount.toLocaleString("en-US")} RWF`;
}

/** Slug-safe id, so DB-backed items keep working as anchors and React keys. */
function slugify(value: string, fallback: string): string {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug.length > 0 ? slug : fallback;
}

/* -------------------------------------------------------------------------- */
/* Menu                                                                       */
/* -------------------------------------------------------------------------- */

type MenuQueryResult = {
  categories: MenuCategoryRow[];
  sections: MenuSectionRow[];
  items: MenuItemRow[];
};

function buildMenu({ categories, sections, items }: MenuQueryResult): MenuCategoryData[] {
  const sectionsByCategory = new Map<string, MenuSectionRow[]>();
  for (const section of sections) {
    const list = sectionsByCategory.get(section.category_id) ?? [];
    list.push(section);
    sectionsByCategory.set(section.category_id, list);
  }

  const itemsBySection = new Map<string, MenuItemRow[]>();
  for (const item of items) {
    const list = itemsBySection.get(item.section_id) ?? [];
    list.push(item);
    itemsBySection.set(item.section_id, list);
  }

  return categories
    .slice()
    .sort((a, b) => a.sort_order - b.sort_order)
    .map((category): MenuCategoryData => {
      const categorySections = (sectionsByCategory.get(category.id) ?? [])
        .slice()
        .sort((a, b) => a.sort_order - b.sort_order)
        .map((section, sectionIndex): MenuSection => {
          const sectionItems = (itemsBySection.get(section.id) ?? [])
            .slice()
            .sort((a, b) => a.sort_order - b.sort_order)
            // `available` is the owner's "86 it for tonight" switch. RLS still
            // returns the row so the admin can see it; the public view hides it.
            .filter((item) => item.available)
            .map(
              (item): MenuItem => ({
                id: slugify(item.name, item.id),
                name: item.name,
                ...(item.description ? { description: item.description } : {}),
                price: formatPrice(item.price),
                ...(item.variants.length > 0
                  ? {
                      variants: item.variants.map((variant) => ({
                        label: variant.label,
                        price: formatPrice(variant.price) ?? "",
                      })),
                    }
                  : {}),
                ...(item.image_url ? { image: item.image_url } : {}),
                ...(item.dietary.length > 0
                  ? { dietary: item.dietary as readonly DietaryTag[] }
                  : {}),
                ...(item.availability_note
                  ? { availability: item.availability_note }
                  : {}),
              }),
            );

          return {
            id: slugify(section.title ?? `${category.slug}-${sectionIndex}`, section.id),
            ...(section.title ? { title: section.title } : {}),
            ...(section.note ? { note: section.note } : {}),
            items: sectionItems,
          };
        })
        // An empty section would render a heading with nothing under it.
        .filter((section) => section.items.length > 0);

      return {
        id: category.slug,
        category: category.name,
        ...(category.intro ? { intro: category.intro } : {}),
        sections: categorySections,
      };
    })
    .filter((category) => category.sections.length > 0);
}

export const getMenu = cache(async (): Promise<readonly MenuCategoryData[]> => {
  if (!isSupabaseConfigured) return staticMenu;

  try {
    const supabase = createSupabasePublicClient();
    if (!supabase) throw new Error("not configured");
    const [categories, sections, items] = await Promise.all([
      supabase.from("menu_categories").select("*").order("sort_order"),
      supabase.from("menu_sections").select("*").order("sort_order"),
      supabase.from("menu_items").select("*").order("sort_order"),
    ]);

    if (categories.error || sections.error || items.error) throw new Error("menu query failed");
    if (!categories.data || categories.data.length === 0) return staticMenu;

    const built = buildMenu({
      categories: categories.data,
      sections: sections.data ?? [],
      items: items.data ?? [],
    });

    return built.length > 0 ? built : staticMenu;
  } catch {
    return staticMenu;
  }
});

/* -------------------------------------------------------------------------- */
/* Business info                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Database values override the committed ones field by field.
 *
 * A partial row must not blank out a phone number that is already correct in
 * the repo, so every field falls back individually rather than the record
 * being replaced wholesale.
 */
export const getRestaurant = cache(async (): Promise<RestaurantData> => {
  if (!isSupabaseConfigured) return staticRestaurant;

  try {
    const supabase = createSupabasePublicClient();
    if (!supabase) throw new Error("not configured");
    const { data, error } = await supabase
      .from("business_info")
      .select("*")
      .eq("id", 1)
      .maybeSingle();

    if (error || !data) return staticRestaurant;

    return {
      ...staticRestaurant,
      name: data.name || staticRestaurant.name,
      legalName: data.legal_name || staticRestaurant.legalName,
      tagline: data.tagline || staticRestaurant.tagline,
      streetAddress: data.street || staticRestaurant.streetAddress,
      city: data.city || staticRestaurant.city,
      country: data.country || staticRestaurant.country,
      plusCode: data.plus_code || staticRestaurant.plusCode,
      email: data.email || staticRestaurant.email,
      website: data.website || staticRestaurant.website,
      directionsUrl: data.directions_url || staticRestaurant.directionsUrl,
      phone: data.phone
        ? { display: formatPhone(data.phone), e164: data.phone }
        : staticRestaurant.phone,
      whatsapp: data.whatsapp
        ? {
            display: formatPhone(data.whatsapp),
            e164: data.whatsapp,
            href: `https://wa.me/${data.whatsapp.replace(/[^\d]/g, "")}`,
          }
        : staticRestaurant.whatsapp,
    };
  } catch {
    return staticRestaurant;
  }
});

/** "+250794317286" -> "+250 794 317 286". */
function formatPhone(e164: string): string {
  const digits = e164.replace(/[^\d]/g, "");
  if (digits.length === 12 && digits.startsWith("250")) {
    return `+${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6, 9)} ${digits.slice(9)}`;
  }
  return e164;
}

/* -------------------------------------------------------------------------- */
/* Hero media                                                                 */
/* -------------------------------------------------------------------------- */

export type HeroVideoContent = Readonly<{
  videoUrl: string;
  posterUrl: string | null;
  title: string | null;
  subtitle: string | null;
}>;

/**
 * The active hero video, or null to fall back to the frame-sequence hero.
 *
 * Returns null unless there is genuinely something to play: an active row, a
 * video URL on it, and the global switch on. A hero that renders an empty
 * <video> is worse than no video at all.
 */
export const getHeroVideo = cache(async (): Promise<HeroVideoContent | null> => {
  if (!isSupabaseConfigured) return null;

  try {
    const supabase = createSupabasePublicClient();
    if (!supabase) throw new Error("not configured");

    const [settings, hero] = await Promise.all([
      supabase.from("site_settings").select("hero_video_enabled").eq("id", 1).maybeSingle(),
      supabase
        .from("hero_media")
        .select("*")
        .eq("is_active", true)
        .maybeSingle<HeroMediaRow>(),
    ]);

    if (settings.data && settings.data.hero_video_enabled === false) return null;
    if (hero.error || !hero.data?.video_url) return null;

    return {
      videoUrl: hero.data.video_url,
      posterUrl: hero.data.poster_url,
      title: hero.data.title,
      subtitle: hero.data.subtitle,
    };
  } catch {
    return null;
  }
});

/* -------------------------------------------------------------------------- */
/* Collections                                                                */
/* -------------------------------------------------------------------------- */

async function selectAll<T>(
  table: "experiences" | "gallery_items" | "offers" | "testimonials" | "social_links",
): Promise<T[]> {
  if (!isSupabaseConfigured) return [];
  try {
    const supabase = createSupabasePublicClient();
    if (!supabase) throw new Error("not configured");
    const { data, error } = await supabase.from(table).select("*").order("sort_order");
    if (error || !data) return [];
    return data as T[];
  } catch {
    return [];
  }
}

export const getExperiences = cache(() => selectAll<ExperienceRow>("experiences"));
export const getGalleryItems = cache(() => selectAll<GalleryItemRow>("gallery_items"));
export const getOffers = cache(() => selectAll<OfferRow>("offers"));
export const getTestimonials = cache(() => selectAll<TestimonialRow>("testimonials"));

/** Social links, falling back to the verified ones in data/restaurant.ts. */
export const getSocialLinks = cache(async () => {
  const rows = await selectAll<SocialLinkRow>("social_links");
  if (rows.length === 0) return staticRestaurant.socials;
  return rows.map((row) => ({
    platform: row.platform,
    label: row.label,
    href: row.url,
  }));
});
